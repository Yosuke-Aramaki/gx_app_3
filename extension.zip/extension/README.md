# Chrome Extension のセットアップ

・[chrome://extensions/]に移動 
・右上でデベロッパーモードに起動 
・「パッケージ化されてない拡張機能を読み込む」ボタンをおす 
・「leo/extension」を選択 
・[chrome-extension://ID/index.html]にてデバッグ 